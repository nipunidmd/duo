/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","zh",{button:"插入程式碼片段",codeContents:"程式碼內容",emptySnippetError:"程式碼片段不可為空白。",language:"語言",title:"程式碼片段",pathName:"程式碼片段"});